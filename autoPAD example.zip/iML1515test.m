%iML1515test

load('iML1515');
tic
%get metKeggID to build the pKa table
iML1515_m=obtainChebiKeggIDForABiGGModel(iML1515,'iML1515_m', 'iML1515');
toc
%get pKa table for iML1515 from metKeggIDs
[pKaTable,report]=constructpKaTableForAModel(iML1515_m,'iML1515 pKa table',1);

%create a new model, adjusted to external pH 5.5, cytoplasmic pH 7.6,
%periplasmic pH 6.
adjusted_iML1515_m=autoPAD(iML1515_m,[7.6 5.5 6],[7.2 7.2 7.2], pKaTable, 'adjusted_iML1515_m');

%compare the changes in both models
compareTwoGSMM(iML1515_m,adjusted_iML1515_m,1,'iML1515 comparison');


